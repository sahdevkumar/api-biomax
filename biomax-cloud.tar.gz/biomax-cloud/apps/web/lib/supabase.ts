import { createClient } from '@supabase/supabase-js'
import type { Database } from './types'

const url  = process.env.NEXT_PUBLIC_SUPABASE_URL!
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const svc  = process.env.SUPABASE_SERVICE_ROLE_KEY!

// Client-side (uses anon key + RLS)
export const supabase = createClient<Database>(url, anon)

// Server-side admin client (bypasses RLS — server only)
export const supabaseAdmin = createClient<Database>(url, svc, {
  auth: { autoRefreshToken: false, persistSession: false },
})
