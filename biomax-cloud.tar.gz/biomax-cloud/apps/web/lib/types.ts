// ─── Database types ──────────────────────────────────────────────────────────

export type DeviceStatus = 'ONLINE' | 'OFFLINE' | 'ERROR'
export type RecordType   = 'CHECK_IN' | 'CHECK_OUT' | 'BREAK_OUT' | 'BREAK_IN' | 'OVERTIME_IN' | 'OVERTIME_OUT'
export type VerifyMode   = 'FINGERPRINT' | 'FACE' | 'CARD' | 'PASSWORD' | 'FACE_FINGERPRINT'
export type CommandStatus = 'PENDING' | 'SENT' | 'SUCCESS' | 'FAILED'
export type UserRole     = 'ADMIN' | 'MANAGER' | 'USER'

export interface Device {
  id: string
  device_id: string
  name: string | null
  ip_address: string | null
  location: string | null
  status: DeviceStatus
  last_seen: string | null
  firmware_version: string | null
  serial_number: string | null
  max_users: number
  max_fingerprints: number
  max_faces: number
  push_version: string | null
  created_at: string
  updated_at: string
}

export interface AppUser {
  id: string
  employee_code: string
  full_name: string
  email: string | null
  department: string | null
  phone: string | null
  role: UserRole
  photo_url: string | null
  created_at: string
}

export interface DeviceUser {
  id: string
  device_id: string
  user_id: string
  device_uid: number
  fingerprint_count: number
  face_enrolled: boolean
  card_number: string | null
  enrolled_at: string
  last_sync_at: string | null
  user?: AppUser
  device?: Device
}

export interface AttendanceLog {
  id: string
  device_id: string
  user_id: string | null
  device_uid: number
  punch_time: string
  record_type: RecordType
  verify_mode: VerifyMode
  temperature: number | null
  mask_worn: boolean | null
  photo_url: string | null
  processed: boolean
  raw_data: Record<string, unknown> | null
  created_at: string
  user?: AppUser
  device?: Device
}

export interface DeviceCommand {
  id: string
  device_id: string
  command: string
  params: Record<string, unknown>
  status: CommandStatus
  result: Record<string, unknown> | null
  executed_at: string | null
  created_at: string
}

// ─── ADMS Protocol types ─────────────────────────────────────────────────────

export interface AdmsHeartbeat {
  SN: string         // Device serial number
  options?: string   // "all" on first connect
  pushver?: string   // "2.0"
  language?: string
  pushOptionsFlag?: string
}

export interface AdmsPunchRecord {
  pin: string        // Employee code / device UID
  time: string       // "2026-03-22 09:15:33"
  status: string     // "0"=check-in "1"=check-out "2-5"=various
  verify: string     // "1"=FP "4"=Card "15"=Face
  workcode?: string
  reserved?: string
}

export interface AdmsUserRecord {
  pin: string
  name: string
  pri: string        // privilege 0=user 14=admin
  password?: string
  card?: string
  grp?: string
  tz?: string
  verify?: string
  vice_card?: string
}

export interface AdmsFpTemplate {
  pin: string
  fid: string        // finger index 0-9
  valid: string
  tmp: string        // base64 template data
  size: string
}

// ─── Supabase Database type stubs (expand as needed) ─────────────────────────

export type Database = {
  public: {
    Tables: {
      devices:         { Row: Device;         Insert: Partial<Device>;         Update: Partial<Device>         }
      users:           { Row: AppUser;         Insert: Partial<AppUser>;         Update: Partial<AppUser>         }
      device_users:    { Row: DeviceUser;      Insert: Partial<DeviceUser>;      Update: Partial<DeviceUser>      }
      attendance_logs: { Row: AttendanceLog;   Insert: Partial<AttendanceLog>;   Update: Partial<AttendanceLog>   }
      device_commands: { Row: DeviceCommand;   Insert: Partial<DeviceCommand>;   Update: Partial<DeviceCommand>   }
    }
  }
}
