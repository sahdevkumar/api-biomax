import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-geist-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-geist-mono)', 'monospace'],
      },
      colors: {
        brand: {
          50:  '#eefaf4',
          100: '#d6f2e3',
          200: '#b0e5cc',
          300: '#7dd1ad',
          400: '#48b58a',
          500: '#289970',
          600: '#1a7b5a',
          700: '#166249',
          800: '#154e3c',
          900: '#134132',
          950: '#09261e',
        },
      },
    },
  },
  plugins: [],
}
export default config
