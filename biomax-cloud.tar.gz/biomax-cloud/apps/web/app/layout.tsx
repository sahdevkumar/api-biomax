import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'BioMax Cloud',
  description: 'Biometric attendance management — serverless, direct ADMS',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
