import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const deviceId  = searchParams.get('device_id')
  const userId    = searchParams.get('user_id')
  const startDate = searchParams.get('start_date')
  const endDate   = searchParams.get('end_date')
  const limit     = Math.min(parseInt(searchParams.get('limit') ?? '100'), 500)

  let query = supabaseAdmin
    .from('attendance_logs')
    .select(`*, user:users(full_name, employee_code, department), device:devices(name, location)`)
    .order('punch_time', { ascending: false })
    .limit(limit)

  if (deviceId)  query = query.eq('device_id',  deviceId)
  if (userId)    query = query.eq('user_id',    userId)
  if (startDate) query = query.gte('punch_time', startDate)
  if (endDate)   query = query.lte('punch_time', endDate + 'T23:59:59')

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}
