import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const dept = searchParams.get('department')

  let query = supabaseAdmin.from('users').select(`
    *, device_users(device_id, device_uid, fingerprint_count, face_enrolled, last_sync_at,
      device:devices(name, location, status))
  `).order('full_name')

  if (dept) query = query.eq('department', dept)

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

const UserSchema = z.object({
  employee_code: z.string().min(1).max(50),
  full_name:     z.string().min(1).max(100),
  email:         z.string().email().optional(),
  department:    z.string().optional(),
  phone:         z.string().optional(),
  role:          z.enum(['ADMIN','MANAGER','USER']).default('USER'),
})

export async function POST(req: NextRequest) {
  const body = await req.json()
  const parsed = UserSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })

  const { data, error } = await supabaseAdmin
    .from('users')
    .insert(parsed.data)
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data, { status: 201 })
}
