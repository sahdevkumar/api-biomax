import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { z } from 'zod'

const UpdateSchema = z.object({
  full_name: z.string().min(1).max(100).optional(),
  email: z.string().email().optional().nullable(),
  department: z.string().max(50).optional().nullable(),
  phone: z.string().max(20).optional().nullable(),
  role: z.enum(['USER','ADMIN','MANAGER']).optional(),
  privilege: z.number().int().min(0).max(14).optional(),
  card_number: z.string().max(50).optional().nullable(),
  password: z.string().max(8).optional().nullable(),
  active: z.boolean().optional(),
})

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const { data, error } = await supabaseAdmin
    .from('users')
    .select(`
      *,
      device_users(*, devices(id, name, location, status)),
      biometric_templates(id, finger_index, valid, created_at, device_id),
      attendance_logs(id, punch_time, record_type, verify_mode, device_id)
    `)
    .eq('id', params.id)
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 404 })
  return NextResponse.json(data)
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const body = await req.json()
  const parsed = UpdateSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })

  const { data, error } = await supabaseAdmin
    .from('users')
    .update(parsed.data)
    .eq('id', params.id)
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  // Get all device enrollments to queue delete commands
  const { data: enrollments } = await supabaseAdmin
    .from('device_users')
    .select('device_id, device_uid')
    .eq('user_id', params.id)

  // Queue DELETE_USER command on each device
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('employee_code')
    .eq('id', params.id)
    .single()

  if (user && enrollments) {
    for (const e of enrollments) {
      await supabaseAdmin.from('device_commands').insert({
        device_id: e.device_id,
        command: 'DELETE_USER',
        params: { pin: user.employee_code },
      })
    }
  }

  const { error } = await supabaseAdmin
    .from('users')
    .update({ active: false })
    .eq('id', params.id)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return new NextResponse(null, { status: 204 })
}
