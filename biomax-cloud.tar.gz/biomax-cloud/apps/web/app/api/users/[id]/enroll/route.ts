/**
 * POST /api/users/[id]/enroll
 * Enroll a user on one or more devices.
 * Queues ADD_USER command + optional biometric enrollment triggers.
 */
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { z } from 'zod'

const EnrollSchema = z.object({
  device_id: z.string().uuid(),
  device_uid: z.number().int().min(1).max(65535),
  enroll_fingerprint: z.boolean().default(false),
  finger_indices: z.array(z.number().int().min(0).max(9)).default([0]),
  enroll_face: z.boolean().default(false),
  push_existing_templates: z.boolean().default(true),
})

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const body = await req.json()
  const parsed = EnrollSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })

  const { device_id, device_uid, enroll_fingerprint, finger_indices, enroll_face, push_existing_templates } = parsed.data

  // Load user
  const { data: user, error: userErr } = await supabaseAdmin
    .from('users')
    .select('*')
    .eq('id', params.id)
    .single()

  if (userErr || !user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  // Create device_user enrollment record
  await supabaseAdmin
    .from('device_users')
    .upsert({
      device_id,
      user_id: params.id,
      device_uid,
      sync_status: 'PENDING',
    }, { onConflict: 'device_id,user_id' })

  const commands: Array<{ command: string; params: Record<string, unknown> }> = []

  // 1. Add user to device
  commands.push({
    command: 'ADD_USER',
    params: {
      pin: user.employee_code,
      name: user.full_name,
      privilege: user.privilege ?? 0,
      password: user.password ?? '',
      card: user.card_number ?? '',
    },
  })

  // 2. Push existing templates if requested
  if (push_existing_templates) {
    const { data: templates } = await supabaseAdmin
      .from('biometric_templates')
      .select('*')
      .eq('user_id', params.id)
      .eq('valid', true)

    for (const tpl of templates ?? []) {
      commands.push({
        command: 'PUSH_TEMPLATE',
        params: {
          pin: user.employee_code,
          fingerIndex: tpl.finger_index ?? 0,
          template: tpl.template,
        },
      })
    }
  }

  // 3. Trigger live biometric enrollment on device
  if (enroll_fingerprint) {
    for (const fi of finger_indices) {
      commands.push({
        command: 'ENROLL_FP',
        params: { pin: user.employee_code, fingerIndex: fi },
      })
    }
  }

  if (enroll_face) {
    commands.push({
      command: 'ENROLL_FACE',
      params: { pin: user.employee_code },
    })
  }

  // Queue all commands
  const rows = commands.map(c => ({ device_id, command: c.command, params: c.params, status: 'PENDING' }))
  const { error: cmdErr } = await supabaseAdmin.from('device_commands').insert(rows)

  if (cmdErr) return NextResponse.json({ error: cmdErr.message }, { status: 500 })

  return NextResponse.json({
    message: `Enrollment queued. ${commands.length} command(s) will be delivered on next heartbeat.`,
    commands: commands.map(c => c.command),
  }, { status: 201 })
}
