/**
 * /api/iclock/cdata
 *
 * GET  — device heartbeat. Returns config + queued commands.
 * POST — device pushes attendance logs (ATTLOG) or user/FP data (OPERLOG).
 */

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import {
  parseAttlog, parseOperlog, parseVerifyMode, parseRecordType,
  buildHeartbeatResponse, cmdGetInfo,
} from '@/lib/adms'

const text = (body: string, status = 200) =>
  new NextResponse(body, {
    status,
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  })

// ─── GET — heartbeat ─────────────────────────────────────────────────────────
export async function GET(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const sn = searchParams.get('SN')
  if (!sn) return text('ERROR: missing SN', 400)

  // Upsert device record, mark online
  const { data: device } = await supabaseAdmin
    .from('devices')
    .upsert(
      { device_id: sn, status: 'ONLINE', last_seen: new Date().toISOString() },
      { onConflict: 'device_id', ignoreDuplicates: false }
    )
    .select('id')
    .single()

  if (!device) return text('ERROR: db error', 500)

  // Fetch pending commands
  const { data: cmds } = await supabaseAdmin
    .from('device_commands')
    .select('id, command, params')
    .eq('device_id', device.id)
    .eq('status', 'PENDING')
    .order('created_at')
    .limit(5)

  const pendingCommands: string[] = []
  const cmdIds: string[] = []

  if (cmds && cmds.length > 0) {
    for (const cmd of cmds) {
      pendingCommands.push(buildCommandString(cmd.id.slice(0, 8), cmd.command, cmd.params as Record<string,string>))
      cmdIds.push(cmd.id)
    }
    // Mark commands as sent
    await supabaseAdmin
      .from('device_commands')
      .update({ status: 'SENT' })
      .in('id', cmdIds)
  }

  // First connect — also queue a GET_INFO command
  const isFirstConnect = searchParams.get('options') === 'all'
  if (isFirstConnect) {
    pendingCommands.push(cmdGetInfo(Date.now() % 100000))
  }

  const stamp = Math.floor(Date.now() / 1000)
  return text(buildHeartbeatResponse({ stamp, delay: 30, realtime: 1, pendingCommands }))
}

// ─── POST — attendance + user/FP data push ───────────────────────────────────
export async function POST(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const sn    = searchParams.get('SN')
  const table = searchParams.get('table')
  if (!sn) return text('ERROR: missing SN', 400)

  // Look up device
  const { data: device } = await supabaseAdmin
    .from('devices')
    .select('id')
    .eq('device_id', sn)
    .single()

  if (!device) return text('ERROR: unknown device', 404)

  const body = await req.text()

  // ── Attendance log push ──────────────────────────────────────────────────
  if (table === 'ATTLOG') {
    const records = parseAttlog(body)
    if (records.length === 0) return text('OK: 0')

    const inserts = []
    for (const r of records) {
      // Resolve user by employee_code (PIN = employee_code)
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('id')
        .eq('employee_code', r.pin)
        .single()

      inserts.push({
        device_id:   device.id,
        user_id:     user?.id ?? null,
        device_uid:  parseInt(r.pin) || 0,
        punch_time:  new Date(r.time).toISOString(),
        record_type: parseRecordType(r.status),
        verify_mode: parseVerifyMode(r.verify),
        processed:   false,
        raw_data:    r,
      })
    }

    const { error } = await supabaseAdmin.from('attendance_logs').insert(inserts)
    if (error) return text(`ERROR: ${error.message}`, 500)
    return text(`OK: ${records.length}`)
  }

  // ── Operator log push (users + fingerprints) ─────────────────────────────
  if (table === 'OPERLOG') {
    const { users, fingerprints } = parseOperlog(body)

    for (const u of users) {
      if (!u.pin || !u.name) continue
      await supabaseAdmin
        .from('users')
        .upsert(
          { employee_code: u.pin, full_name: u.name, role: u.pri === '14' ? 'ADMIN' : 'USER' },
          { onConflict: 'employee_code', ignoreDuplicates: false }
        )
    }

    // Store fingerprint templates in device_users
    for (const fp of fingerprints) {
      const { data: user } = await supabaseAdmin
        .from('users')
        .select('id')
        .eq('employee_code', fp.pin)
        .single()
      if (!user) continue
      await supabaseAdmin
        .from('device_users')
        .upsert(
          { device_id: device.id, user_id: user.id, device_uid: parseInt(fp.pin), fingerprint_count: 1 },
          { onConflict: 'device_id,device_uid', ignoreDuplicates: false }
        )
    }

    return text(`OK: ${users.length} users, ${fingerprints.length} templates`)
  }

  return text('OK')
}

// ─── Helper: serialise queued command row back to ADMS string ─────────────────
function buildCommandString(shortId: string, command: string, params: Record<string,string>): string {
  const id = parseInt(shortId, 16) % 100000
  const paramStr = Object.entries(params).map(([k,v]) => `${k}=${v}`).join('\t')
  return `C:${id}:${command}${paramStr ? '\t' + paramStr : ''}`
}
