/**
 * /api/iclock/getrequest
 * Device polls this to receive pending commands (alternative to inline delivery).
 */
import { NextRequest } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { buildCommand, generateAdmsId } from '@/lib/adms'

export const runtime = 'nodejs'

export async function GET(req: NextRequest) {
  const sn = req.nextUrl.searchParams.get('SN')
  if (!sn) return new Response('ERROR', { status: 400 })

  const { data: device } = await supabaseAdmin
    .from('devices')
    .select('id')
    .eq('device_id', sn)
    .single()

  if (!device) return new Response('OK', { status: 200 })

  const { data: cmds } = await supabaseAdmin
    .from('device_commands')
    .select('*')
    .eq('device_id', device.id)
    .eq('status', 'PENDING')
    .order('created_at', { ascending: true })
    .limit(3)

  if (!cmds || cmds.length === 0) return new Response('OK', { status: 200 })

  const lines: string[] = []
  for (const cmd of cmds) {
    const admsId = generateAdmsId()
    lines.push(buildCommand(admsId, cmd.command as any, cmd.params as Record<string, unknown>))
    await supabaseAdmin
      .from('device_commands')
      .update({ status: 'SENT', adms_id: admsId, sent_at: new Date().toISOString() })
      .eq('id', cmd.id)
  }

  return new Response(lines.join('\r\n') + '\r\n', {
    headers: { 'Content-Type': 'text/plain' },
  })
}
