/**
 * /api/iclock/devicecmd
 * Device ACKs a command result back to the server.
 * Body: "ID=295&Return=0&CMD=DATA UPDATE\nContent..."
 */

import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

const text = (body: string, status = 200) =>
  new NextResponse(body, { status, headers: { 'Content-Type': 'text/plain' } })

export async function POST(req: NextRequest) {
  const { searchParams } = req.nextUrl
  const sn = searchParams.get('SN')
  if (!sn) return text('ERROR: missing SN', 400)

  const body = await req.text()
  const params = Object.fromEntries(
    body.split('&').map(p => {
      const idx = p.indexOf('=')
      return [p.slice(0, idx), p.slice(idx + 1)]
    })
  )

  const cmdId   = params['ID']
  const retCode = params['Return']
  const cmdName = params['CMD']

  if (!cmdId) return text('OK')

  // Find the command by matching short ID encoded in the command
  const { data: device } = await supabaseAdmin
    .from('devices')
    .select('id')
    .eq('device_id', sn)
    .single()

  if (device) {
    // Mark as success or failed based on return code
    const status = retCode === '0' ? 'SUCCESS' : 'FAILED'
    await supabaseAdmin
      .from('device_commands')
      .update({
        status,
        result: { return_code: retCode, cmd: cmdName, raw: body },
        executed_at: new Date().toISOString(),
      })
      .eq('device_id', device.id)
      .eq('status', 'SENT')
      .order('created_at')
      .limit(1)
  }

  return text('OK')
}
