/**
 * /api/devices
 * GET  — list all devices
 * POST — register a device manually or queue a command
 */

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { supabaseAdmin } from '@/lib/supabase'
import { cmdAddUser, cmdDeleteUser, cmdEnrollBio, cmdSyncTime, cmdReboot, cmdPushTemplate, cmdQueryUsers } from '@/lib/adms'

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from('devices')
    .select('*')
    .order('created_at', { ascending: false })
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

const RegisterSchema = z.object({
  device_id: z.string().min(1),
  name:      z.string().optional(),
  location:  z.string().optional(),
})

export async function POST(req: NextRequest) {
  const body = await req.json()
  const parsed = RegisterSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })

  const { data, error } = await supabaseAdmin
    .from('devices')
    .upsert(parsed.data, { onConflict: 'device_id' })
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data, { status: 201 })
}
