/**
 * POST /api/devices/[id]/commands
 * Queue a command for a device. Delivered on next heartbeat (~30s).
 *
 * Body: { command: CommandType, params: {} }
 *
 * Supported commands:
 *   ADD_USER      { pin, name, privilege?, password?, card? }
 *   DELETE_USER   { pin }
 *   ENROLL_FP     { pin, fingerIndex? }
 *   ENROLL_FACE   { pin }
 *   PUSH_TEMPLATE { pin, fingerIndex, template }
 *   DELETE_TEMPLATE { pin, fingerIndex? }
 *   SET_TIME      {}
 *   REBOOT        {}
 *   GET_INFO      {}
 *   CLEAR_LOGS    {}
 */
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { z } from 'zod'

const CommandSchema = z.object({
  command: z.enum([
    'ADD_USER','DELETE_USER','ENROLL_FP','ENROLL_FACE',
    'PUSH_TEMPLATE','DELETE_TEMPLATE','SET_TIME','REBOOT','GET_INFO','CLEAR_LOGS',
  ]),
  params: z.record(z.unknown()).default({}),
})

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const { data, error } = await supabaseAdmin
    .from('device_commands')
    .select('*')
    .eq('device_id', params.id)
    .order('created_at', { ascending: false })
    .limit(50)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const body = await req.json()
  const parsed = CommandSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })

  // Verify device exists
  const { data: device } = await supabaseAdmin
    .from('devices')
    .select('id, status')
    .eq('id', params.id)
    .single()

  if (!device) return NextResponse.json({ error: 'Device not found' }, { status: 404 })

  const { data: cmd, error } = await supabaseAdmin
    .from('device_commands')
    .insert({
      device_id: params.id,
      command: parsed.data.command,
      params: parsed.data.params,
      status: 'PENDING',
    })
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({
    ...cmd,
    message: `Command queued. Will be delivered on next device heartbeat (within ${30}s).`,
  }, { status: 201 })
}
