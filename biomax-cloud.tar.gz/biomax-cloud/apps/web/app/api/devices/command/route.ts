/**
 * /api/devices/command
 * POST — queue a management command for a device
 *
 * Supported commands:
 *   ADD_USER, DELETE_USER, ENROLL_FP, ENROLL_FACE,
 *   PUSH_TEMPLATE, SYNC_TIME, REBOOT, QUERY_USERS, GET_INFO
 */

import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { supabaseAdmin } from '@/lib/supabase'

const CommandSchema = z.object({
  device_id: z.string().uuid(),
  command:   z.enum(['ADD_USER','DELETE_USER','ENROLL_FP','ENROLL_FACE','PUSH_TEMPLATE','SYNC_TIME','REBOOT','QUERY_USERS','GET_INFO']),
  params:    z.record(z.string()).optional().default({}),
})

export async function POST(req: NextRequest) {
  const body = await req.json()
  const parsed = CommandSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })

  const { device_id, command, params } = parsed.data

  // Map command enum to ADMS command string
  const commandMap: Record<string, string> = {
    ADD_USER:      'DATA UPDATE USER',
    DELETE_USER:   'DATA DELETE USER',
    ENROLL_FP:     'ENROLL_BIO',
    ENROLL_FACE:   'ENROLL_BIO',
    PUSH_TEMPLATE: 'DATA UPDATE TEMPLATEV10',
    SYNC_TIME:     'SET OPTIONS',
    REBOOT:        'SET OPTIONS',
    QUERY_USERS:   'DATA QUERY USER',
    GET_INFO:      'GET OPTIONS',
  }

  // Enrich params for specific commands
  const enrichedParams = { ...params }
  if (command === 'ENROLL_FP')   enrichedParams['Type'] = '1'
  if (command === 'ENROLL_FACE') enrichedParams['Type'] = '9'
  if (command === 'SYNC_TIME')   enrichedParams['DateTime'] = new Date().toISOString()
  if (command === 'REBOOT')      enrichedParams['Reboot'] = '1'
  if (command === 'GET_INFO')    enrichedParams['Fields'] = '~SN,~ProductName,~FirmVer,~UserCount,~FPCount,~FaceCount'

  const { data, error } = await supabaseAdmin
    .from('device_commands')
    .insert({
      device_id,
      command:    commandMap[command],
      params:     enrichedParams,
      status:     'PENDING',
    })
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ queued: true, command: data }, { status: 201 })
}
