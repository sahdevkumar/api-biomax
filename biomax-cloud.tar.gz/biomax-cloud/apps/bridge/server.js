/**
 * BioMax Local Bridge — Optional TCP management layer
 *
 * Use this ONLY if you need:
 *   - Sub-second instant TCP commands (vs 30s ADMS polling)
 *   - Offline punch queueing at the local network level
 *   - Direct TCP SDK access to legacy devices without ADMS support
 *
 * For most deployments, the ADMS direct mode (no bridge) is sufficient.
 *
 * Requirements: Raspberry Pi / Linux machine on the same LAN as devices.
 * Run: docker compose up  OR  node server.js
 */

'use strict'
require('dotenv').config()

const { createClient } = require('@supabase/supabase-js')

// ─── Config ──────────────────────────────────────────────────────────────────
const SUPABASE_URL      = process.env.SUPABASE_URL      || process.env.NEXT_PUBLIC_SUPABASE_URL
const SUPABASE_SVC_KEY  = process.env.SUPABASE_SERVICE_ROLE_KEY
const POLL_INTERVAL_MS  = parseInt(process.env.POLL_INTERVAL_MS  || '5000')
const DEVICES_JSON      = process.env.DEVICES_JSON || '[]'
// Format: '[{"id":"<uuid>","ip":"192.168.1.201","port":4370}]'

if (!SUPABASE_URL || !SUPABASE_SVC_KEY) {
  console.error('[bridge] SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required')
  process.exit(1)
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SVC_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
})

let deviceConfigs = []
try { deviceConfigs = JSON.parse(DEVICES_JSON) } catch {}

// ─── Device connection pool ───────────────────────────────────────────────────
const connections = new Map() // device_id → ZK instance

async function getConnection(cfg) {
  if (connections.has(cfg.id)) return connections.get(cfg.id)

  // Lazily require — only needed when bridge is actually used
  let ZK
  try { ZK = require('zk-attendance-sdk') }
  catch { throw new Error('zk-attendance-sdk not installed. Run: npm install in apps/bridge/') }

  const zk = new ZK(cfg.ip, cfg.port || 4370, 5200, 0)
  await zk.createSocket()
  connections.set(cfg.id, zk)
  console.log(`[bridge] Connected to device ${cfg.id} @ ${cfg.ip}`)
  return zk
}

function dropConnection(cfg) {
  const zk = connections.get(cfg.id)
  if (zk) { try { zk.disconnect() } catch {} connections.delete(cfg.id) }
}

// ─── Command executor ─────────────────────────────────────────────────────────
async function executeCommand(cfg, cmd) {
  const zk = await getConnection(cfg)
  const p  = cmd.params || {}

  switch (cmd.command) {
    case 'DATA UPDATE USER': {
      await zk.setUser(
        parseInt(p.PIN || '1'),
        p.PIN, p.Name || '',
        p.Passwd || '', p.Card || '',
        parseInt(p.Pri || '0')
      )
      return { ok: true }
    }
    case 'DATA DELETE USER': {
      await zk.deleteUser(parseInt(p.PIN || '1'))
      return { ok: true }
    }
    case 'SET OPTIONS': {
      if (p.Reboot === '1') { await zk.restart(); return { ok: true } }
      if (p.DateTime) { await zk.setTime(new Date(p.DateTime)); return { ok: true } }
      return { ok: false, error: 'Unknown SET OPTIONS param' }
    }
    case 'GET OPTIONS': {
      const info = await zk.getInfo()
      return { ok: true, data: info }
    }
    case 'DATA QUERY USER': {
      const users = await zk.getUsers()
      return { ok: true, data: users }
    }
    case 'ENROLL_BIO': {
      // TCP enrollment: trigger on-device capture
      const type = parseInt(p.Type || '1')
      const fid  = parseInt(p.FID  || '0')
      const uid  = parseInt(p.PIN  || '1')
      if (type === 1) await zk.enrollUser(uid, fid)
      // Face enrollment varies by firmware — log for now
      return { ok: true, message: 'Enrollment triggered on device' }
    }
    default:
      return { ok: false, error: `Unknown command: ${cmd.command}` }
  }
}

// ─── Attendance sync ──────────────────────────────────────────────────────────
async function syncAttendance(cfg) {
  let zk
  try { zk = await getConnection(cfg) } catch (e) { return }

  const logs = await zk.getAttendances()
  if (!logs || logs.data.length === 0) return

  const { data: device } = await supabase
    .from('devices')
    .select('id')
    .eq('device_id', cfg.id)
    .single()
  if (!device) return

  const inserts = logs.data.map(r => ({
    device_id:   device.id,
    device_uid:  r.deviceUserId,
    punch_time:  new Date(r.attendanceTime).toISOString(),
    record_type: ['CHECK_IN','CHECK_OUT','BREAK_OUT','BREAK_IN','OVERTIME_IN','OVERTIME_OUT'][r.verifyType] || 'CHECK_IN',
    verify_mode: ['PASSWORD','FINGERPRINT','FINGERPRINT','FINGERPRINT','CARD','CARD','FINGERPRINT','FINGERPRINT','FINGERPRINT','FINGERPRINT','FACE'][r.verifyType] || 'FINGERPRINT',
    processed:   false,
    raw_data:    r,
  }))

  await supabase.from('attendance_logs').upsert(inserts, {
    onConflict: 'device_id,device_uid,punch_time',
    ignoreDuplicates: true,
  })

  console.log(`[bridge] Synced ${inserts.length} attendance records from ${cfg.id}`)
}

// ─── Command poll loop ────────────────────────────────────────────────────────
async function pollCommands(cfg) {
  const { data: device } = await supabase
    .from('devices')
    .select('id')
    .eq('device_id', cfg.id)
    .single()
  if (!device) return

  const { data: cmds } = await supabase
    .from('device_commands')
    .select('*')
    .eq('device_id', device.id)
    .eq('status', 'PENDING')
    .order('created_at')
    .limit(5)

  if (!cmds || cmds.length === 0) return

  for (const cmd of cmds) {
    console.log(`[bridge] Executing: ${cmd.command} on ${cfg.id}`)
    try {
      const result = await executeCommand(cfg, cmd)
      await supabase
        .from('device_commands')
        .update({ status: result.ok ? 'SUCCESS' : 'FAILED', result, executed_at: new Date().toISOString() })
        .eq('id', cmd.id)
    } catch (err) {
      console.error(`[bridge] Command failed: ${err.message}`)
      dropConnection(cfg)
      await supabase
        .from('device_commands')
        .update({ status: 'FAILED', result: { error: err.message }, executed_at: new Date().toISOString() })
        .eq('id', cmd.id)
    }
  }
}

// ─── Update device heartbeat ──────────────────────────────────────────────────
async function updateDeviceStatus(cfg, status) {
  await supabase
    .from('devices')
    .upsert(
      { device_id: cfg.id, status, last_seen: new Date().toISOString() },
      { onConflict: 'device_id', ignoreDuplicates: false }
    )
}

// ─── Main loop ────────────────────────────────────────────────────────────────
async function tick(cfg) {
  try {
    await pollCommands(cfg)
    await updateDeviceStatus(cfg, 'ONLINE')
  } catch (err) {
    console.error(`[bridge] Tick error for ${cfg.id}: ${err.message}`)
    dropConnection(cfg)
    await updateDeviceStatus(cfg, 'OFFLINE')
  }
}

async function main() {
  if (deviceConfigs.length === 0) {
    console.warn('[bridge] No devices configured. Set DEVICES_JSON env var.')
    console.warn('[bridge] Example: [{"id":"<supabase-device-uuid>","ip":"192.168.1.201","port":4370}]')
  }

  console.log(`[bridge] Starting — polling every ${POLL_INTERVAL_MS}ms for ${deviceConfigs.length} device(s)`)

  // Initial attendance sync on startup
  for (const cfg of deviceConfigs) {
    syncAttendance(cfg).catch(e => console.error(`[bridge] Sync error: ${e.message}`))
  }

  // Poll loop
  setInterval(async () => {
    for (const cfg of deviceConfigs) await tick(cfg)
  }, POLL_INTERVAL_MS)
}

main()
